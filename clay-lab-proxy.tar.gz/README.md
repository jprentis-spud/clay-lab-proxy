# Clay Lab Proxy

Lightweight proxy server for **The Clay Lab** — sits between the frontend artifact and Clay's MCP server via the Anthropic API. Keeps API keys secure server-side.

## Architecture

```
[Artifact in Claude.ai]
        │
        │  POST /enrich { domain: "figma.com" }
        ▼
[Clay Lab Proxy on Railway]
        │
        │  Anthropic SDK + Clay MCP Server
        ▼
[api.anthropic.com + api.clay.com/v3/mcp]
        │
        │  Enriched company data + contacts
        ▼
[Structured JSON response back to artifact]
```

## Deploy to Railway

### 1. Push to GitHub

```bash
cd clay-proxy
git init
git add .
git commit -m "Clay Lab proxy server"
gh repo create clay-lab-proxy --private --source=. --push
```

### 2. Create Railway service

- Go to [railway.app](https://railway.app)
- New Project → Deploy from GitHub Repo → select `clay-lab-proxy`

### 3. Set environment variables

In Railway dashboard → Variables:

| Variable | Value |
|----------|-------|
| `ANTHROPIC_API_KEY` | Your Anthropic API key |
| `ALLOWED_ORIGINS` | `https://claude.ai,https://www.claude.ai` (or `*` for testing) |

> **Note**: You do NOT need a Clay API key here. The Clay MCP server authenticates via Anthropic's MCP connector system. However, the Anthropic API key must be from an account that has Clay MCP server access configured, OR you can swap the MCP approach for direct Clay API calls if needed.

### 4. Get your Railway URL

Once deployed, Railway will give you a URL like:
```
https://clay-lab-proxy-production-xxxx.up.railway.app
```

### 5. Update the artifact

Replace the `PROXY_URL` constant in the Clay Lab artifact with your Railway URL.

## API

### `GET /`
Health check. Returns service status.

### `POST /enrich`
Enrich a company domain via Clay MCP.

**Request:**
```json
{ "domain": "figma.com" }
```

**Response (success):**
```json
{
  "ok": true,
  "data": {
    "company": { "name": "Figma", "domain": "figma.com", ... },
    "icpScore": 87,
    "icpBreakdown": [...],
    "signals": [...],
    "contacts": [...],
    "playSteps": [...]
  }
}
```

**Response (error):**
```json
{
  "ok": false,
  "error": "Error message",
  "rawTexts": ["..."],
  "toolResults": ["..."]
}
```

## Rate Limiting

- 10 requests per IP per 60-second window
- Returns 429 when exceeded

## Local Development

```bash
npm install
ANTHROPIC_API_KEY=sk-ant-... npm run dev
```

Test:
```bash
curl -X POST http://localhost:3000/enrich \
  -H "Content-Type: application/json" \
  -d '{"domain":"figma.com"}'
```
